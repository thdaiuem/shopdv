<?php
require_once '../../_config.php';
$cookie = 'sb=WRDMYKXSU8O5yY1KLIrLUXhT; datr=WRDMYPhfqFJTaYcsUFC8wz7O; locale=vi_VN; wd=1876x963; c_user=100013034588090; xs=20%3Apig5tF6RVIgGsg%3A2%3A1624009001%3A-1%3A6205; fr=1dZAANbUv80bSVS5Y.AWWPMBIfyWwzLHQM8ZAYtiO5rWA.BgzF9d.ul.AAA.0.0.BgzGkp.AWUrAUbkg-Y; spin=r.1003995168_b.trunk_t.1624009003_s.1_v.2_';
$return = array('error' => 0);
$url    = curl($_GET['idfb'], $cookie);
if (preg_match('#name="target" value="(.+?)"#is', $url, $hongphuc)) {
    $userId = $hongphuc[1];
}
if (preg_match('#<title>(.+?)</title>#is', $url, $hongphuc)) {
    $fullName = $hongphuc[1];
}
if (isset($fullName) && isset($userId)) {
    $return['msg']  = 'Lấy thành công';
    $return['id']   = $userId;
    $return['name'] = $fullName;
    die(json_encode($return));
} else {
    $return['error'] = 1;
    $return['msg']   = 'Có gì đó không ổn.';
    die(json_encode($return));
}
?>